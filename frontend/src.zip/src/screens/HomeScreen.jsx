import Hero from '../components/Hero';

const HomeScreen = () => {
  return <Hero />;
};
export default HomeScreen;
